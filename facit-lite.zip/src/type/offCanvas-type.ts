export type TOffCanvasPlacement = 'start' | 'top' | 'end' | 'bottom';
